import {Component} from '@angular/core';
import {Iemployee} from './iemployee';
import { EmployeeService } from './employee.service';

@Component({
    selector: 'app-server',
    templateUrl: './server.component.html',
    styleUrls: ['./server.component.scss'],
    providers:[EmployeeService]
})
    
export class ServerComponent {
   employees:Iemployee[];
   
   selectedEmployeeRadio:string="All";
    
    constructor(private _employeeService : EmployeeService){
        this.employees = this._employeeService.getEmployees();
    }
    
    onEmployeeRadioChanged(selectedRadio:string):void{
        this.selectedEmployeeRadio=selectedRadio;
    }
    
    
    getTotalEmployeesCount():number{
        return this.employees.length;
    }
    
    getMaleEmployeesCount():number{
        return this.employees.filter(e=>e.gender==="Male").length;
    }
    
    getFemaleEmployeesCount():number{
        return this.employees.filter(e=>e.gender==="Female").length;
    }

    
    
}