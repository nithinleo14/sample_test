export interface Iemployee{
    code: number;
    name:string;
    age:number;
    dob:string;
    gender:string;
}

// export class Employee implements Iemployee {
//     constructor(public code:number, 
//                 public name:string,
//                 public age:number,
//                 public dob:string,
//                 public gender:string){};
// }