import {Injectable} from '@angular/core';
import {Iemployee} from './iemployee';

@Injectable()
export class EmployeeService {
    getEmployees() : Iemployee[]{
        return [ {code:1,name:'Leo',age:25,dob: '08/07/1992',gender:"Male"},
            {code:2,name:'Nithin',age:26,dob: '01/09/1992',gender:"Male"},
            {code:3,name:'Anisha',age:28,dob: '06/02/1992',gender:"Female"},
            {code:4,name:'Srilekha',age:29,dob: '24/12/1992',gender:"Female"}
            ]
    }
}