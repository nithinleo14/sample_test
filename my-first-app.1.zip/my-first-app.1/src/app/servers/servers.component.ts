import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.scss']
})
export class ServersComponent implements OnInit {
  
 selectedRadio:string='All';
  
  @Output()
  selectedRadioButton: EventEmitter<string> = new EventEmitter<string>();
 
  @Input()
  all:number;
  
  @Input()
  male:number;
  
  @Input()
  female:number;

  constructor() {
  }

  ngOnInit() {
  }
  
  onRadioChanged(){
    this.selectedRadioButton.emit(this.selectedRadio);
    console.log(this.selectedRadio);
  }
  
}
