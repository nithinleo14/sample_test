import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';

@Component({
    selector: 'simple',
    template:`You entered: {{simpleinput}} 
    <input type="text" value="{{simpleinput}}">`
})

export class SimpleComponent implements OnChanges{
    
    @Input() simpleinput:string;
    
    ngOnChanges(changes:SimpleChanges){
        console.log("Changes"+changes+"\n==========")
        for(let propertyName in changes){
            console.log("PropertyName "+changes[propertyName]);
            let change = changes[propertyName];
            let current = JSON.stringify(change.currentValue);
            let previous = JSON.stringify(change.previousValue);
            console.log(propertyName+': currentValue =' + current + ", previousValue=" + previous);
        }
    }
}